const galleryData = [
  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Breakfast',
  },
  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Tasty burger',
  },
  {
    img: 'https://via.placeholder.com/600x400',
    title: 'Camera',
  },
  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Morning',
  },
  {
    img: 'https://via.placeholder.com/600x400',
    title: 'Hats',
  },
  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Honey',
  },
  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Vegetables',
  },
  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Water plant',
  },
  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Mushrooms',
  },
  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Olive oil',
  },
  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Sea star',
  },
  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Bike'
  },
];

export default galleryData;
